from django.apps import AppConfig


class SskuserConfig(AppConfig):
    name = 'sskUser'
