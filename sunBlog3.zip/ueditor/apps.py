from django.apps import AppConfig


class UeditorConfig(AppConfig):
    name = 'apps.ueditor'
